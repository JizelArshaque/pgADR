export class VideoCallChat{
    Id:number=0;
    VideoCallId:number=0;
    Message:string='';
    UserId:number=0;
    Status:number=0;
    MessageType:number=0;
    FileUrl:string='';
    Systime:string='';
    Base64Data:string=''
    }
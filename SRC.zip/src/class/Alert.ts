export class Alert{
    Message:string = '';
    Type:number = 0;
}
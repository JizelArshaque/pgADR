export class AddLaweyers {
    Id: any
    SecretCode: string = '';
  }
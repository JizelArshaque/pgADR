

export class SaveLoginsDetail{
    Email: string = '';
    UserId: number = 0;
    SecretCode: string = '';
    LoginTime: string = '';
    LogoutTime: string = '';

  }




export class ReportIssue{
    Name:string='';
    Email:string='';
    Mobile:string='';
    Message:string='';
    Country:string='';
    ReportType:number=0;
    Id:number=0;
    UserId :number=0;
    Status:number=0;
    Systime:string='';
    ArbitrationId :number=0;
}
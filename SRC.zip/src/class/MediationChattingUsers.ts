export class MediationChattingUsers {

  }
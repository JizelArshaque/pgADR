export class DigitalSign {
    Id:number=0;
    ArbId:number=0;
    PersonImage:string='';
    DigitalSign:string='';
    Location:string='';

}
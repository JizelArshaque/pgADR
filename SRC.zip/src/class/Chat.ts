import { MediationChattingUsers } from './MediationChattingUsers';
export class Chat {
    Id:number=0;
    MediationId:number=0;
    Name: string = '';
    UserId:number=0;
    MediationChattingUsers: MediationChattingUsers[] = [];

  }
// import { Injectable } from '@angular/core';
// import { Socket } from 'ngx-socket-io';

// @Injectable({
//   providedIn: 'root'
// })
// export class SocketService {

//   constructor(private socket: Socket) { }
//   connect() {
//     this.socket.connect();
//   }

//   sendMessage(msg: string) {
//     this.socket.emit('chat message', msg);
//   }

//   onMessage() {
//     return this.socket.fromEvent('chat message');
//   }
// }

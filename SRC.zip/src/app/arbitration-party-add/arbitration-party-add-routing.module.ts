// import { NgModule } from '@angular/core';
// import { Routes, RouterModule } from '@angular/router';

// import { ArbitrationPartyAddPage } from './arbitration-party-add.page';

// const routes: Routes = [
//   {
//     path: '',
//     component: ArbitrationPartyAddPage
//   }
// ];

// @NgModule({
//   imports: [RouterModule.forChild(routes)],
//   exports: [RouterModule],
// })
// export class ArbitrationPartyAddPageRoutingModule {}

import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AddDigitalSignPage } from './add-digital-sign.page';

describe('AddDigitalSignPage', () => {
  let component: AddDigitalSignPage;
  let fixture: ComponentFixture<AddDigitalSignPage>;


  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

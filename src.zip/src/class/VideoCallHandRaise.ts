export class VideoCallHandRaise{
    Id:number=0;
    VideoCallId:number=0;
    UserId:number=0;
    Status:number=0;
    Systime:string='';
    }
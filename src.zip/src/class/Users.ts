// import { UserRightsList } from './UserRightsList';

export class Users{
    Id:number=0;
    Name:string='';
    Email:string='';
    Mobile:string='';
    UserType:number=0;
    Password:string='';
    CreatorId:number=0;
    Address:string='';
    Notification:number=0;
    Status:number=0;
    // UserRightsList:UserRightsList[]=[];
    LastName:string='';
    PhoneCode:string='';
    Country:number=0;
    Nationality:number=0;
    DateOfBirth:string='';
    Pincode:string='';
    UserName:string='';
    CountryName:string='';
    FranchisePackCount:number=0;
    Systime:string='';
    NationalityName:string='';
    LinkedId:number=0;
    SubUserId:number=0;
    OtpStatus:number=0; 
    EmailOtpStatus:number=0;
    EmailOtp:string='';
    TagLahStatus:number=0; 
    JobLahStatus:number=0; 
    StudyLahStatus:number=0; 
    CVStatus:number=0; 
    StudentLahStatus:number=0; 
    DefaultDashboard:number=0;
}
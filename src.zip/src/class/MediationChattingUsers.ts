export class MediationChattingUsers {

  }
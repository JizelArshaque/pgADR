

export class VideoCallUser{
    Id:number=0;
    VideoCallId:number=0;
    UserId:number=0;
    Mobile:string = '';
    Name:string = '';
    Email:string = '';
    Status:number=0;
    Systime:string='';
    IsAudioMute:number = 0;
    IsVideoMute:number=0;

    isHostLeavingCall:number =0;
    Token:string='';
    Channel:string='';
    Uname:string = '';
    }
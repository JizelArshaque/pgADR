export class VideoStoreOrderItemss{
    Id:number=0;
    ItemId:number=0;
    ItemName:string='';
    Quantity:number=0;
    Rate:number=0;
    Tax:number=0;
    Status:number=0;
    Systime:string='';
}
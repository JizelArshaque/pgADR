


export class UserDetails{
    checktype:number=0;
    UserName: string = '';
    Password: string = '';
    Email: string = '';
    Mobile: string = '';
    Status: number = 0;
    Id: number = 0;
    UserId: number = 0;
    Otp: string = '';
    UserType: number = 0;
    UserTypeId: number = 0;
    Name: string = '';
    Address: string = '';
    DOB: string = '';
    District: string = '';
    State: string = '';
    Country: string = '';
    BloodGroup: string = '';
    ProfessionalDetails: string = '';
    EducationDetails: string = '';
    IdCardTypeId: number = 0;
    IdCardNumber: string = '';
    Gender: number = 0;
    MaritalStatus: number = 0;
    SysTime: string = '';
    IsPledgeSigned: number = 1;
    PledgeSignedTime: string = '';
    CentersId: number = 8; 
    ServicesId: number = 0;
    TimeBankAccountNumber: string = '';
    MembershipAccountNumber: string = '';
    Nominee: string = '';
   

    Relationship: string = '';
    Amount: number = 0;
    Code: string = '';
    Type: number = 0;
    IsReviewer: number = 0;
    ReviewerId: number = 0;
    Age: number = 0;
    TimebankRegisterStatus: number = 0;
    IsEdit: number = 0;
    ShoppingId: string = '';
    ShoppingUserName: string = '';
    ShoppingName: string = '';
    Biodata: string = '';
    Languages: string = '';
    CategoryId: number = 0;
    CategoryName: string = '';
    ReviewerName: string = '';
    Centres: string = '';
    PMSStatus: number = 0;
    AMAPCount: number = 0;
    OTPStatus: number = 0;
    
    MediatorStatus: number = 0;
    ArbitratorStatus: number = 0;
    MediationAdvocateStatus: number = 0;
    MediatorTrainingDetails: string = '';
    MediationStyle: string = '';
    ArbitratorTrainingDetails: string = '';
    ArbitratorCategory: string = '';
    EmmergencyArbitrator: number = 0;
    MediationAdvocateTrainingDetails: string = '';
    MediationAdvocateCategory: string = '';
    MediatorDigest:string='';
    UserImage:string='';

    PMSAuthorisedDate:string='';
    TBAuthorisedDate:string='';
    MediatorAuthorisedDate:string='';
    ArbitratorAuthorisedDate:string='';
    AdvocateAuthorisedDate:string='';
    TotalAmount:number=0;
    GSTAmount:number=0;
    CessAmount:number=0;
    MediationCertificate:string='';
    ApcamMediationCertificate:string='';
    ApcamArbitratorCategory:string='';
   IsProjectMediator:number=0;

   MediatorExpiryDate:string='';
   ArbitratorExpiryDate:string='';
   APCAMMediatorExpiryDate:string='';
   APCAMArbitratorExpiryDate:string='';
    AdvocateExpiryDate:string='';
//    ImageUrl:string='';

    TBExpiry:string='';
    MediatorCertificate_old:string='';
    IIAMMediatorCertificate_old:string='';
    ArbitratorCategory_old:string='';
    ApcamArbitratorCategory_old:string='';
    mediationadvocatecategory_old:string='';
    acceptance:number=0;
Systime:string='';
    AccountName:string='';
    AccountNo:string='';
    BankandBranch:string='';
    IFSCCode:string='';
    BankDetailsStatus:number=0;
    CountryCode:string='+91';
    IsPeacePledgeSigned:number=0;
    Page:string='';
    LiveCases:number=0;
    Count:number=0;
    PANNo:number=0;
    IsOnlineMediator:number=0;
    IsExpeditedArbitrator:number=0;
  }



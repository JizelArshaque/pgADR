export class ArbitrationParties {
  Id: number=0;
  ArbitrationId: number=0;
  UserId: number=0;
  SecureCode:string='';
  AddedBy:number=0;
  Name: string = '';
  Mobile: string = '';
  Email: string = '';
  Address: string = '';
  Type: number = 0;
  Side: number=0;
  AuthorisationUrl:string=''
  Country: string = '';
  State: string = '';
  City: string = '';
  IsController:number=0;
  Password: string = '';
  Status: number = 0;
  AppearFor  : string='';
  Designation:string='';

   
  }







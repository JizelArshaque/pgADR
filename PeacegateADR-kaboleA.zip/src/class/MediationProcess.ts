export class MediationProcess
{
MediationId:number=0;
MediatorId:number=0;
MediationStage:number=0;
MediationStatusType:number=0;
MediationStatusValue:number=0;
Systime:string='';
}
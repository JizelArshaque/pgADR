export class TribunalPreferenceRating{
    ArbitrationId: number = 0;
    ArbitrationPartyId: number = 0;
    TribunalId: number = 0;
    Preference: number = 0;
    Reason: string = '';

  }


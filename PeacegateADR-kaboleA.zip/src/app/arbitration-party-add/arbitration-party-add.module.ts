// import { NgModule } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { FormsModule } from '@angular/forms';

// import { IonicModule } from '@ionic/angular';

// import { ArbitrationPartyAddPageRoutingModule } from './arbitration-party-add-routing.module';

// import { ArbitrationPartyAddPage } from './arbitration-party-add.page';
// import { IonicSelectableComponent } from 'ionic-selectable';


// @NgModule({
//   imports: [
//     CommonModule, 
//     FormsModule,
//     IonicModule, 
//     ArbitrationPartyAddPageRoutingModule,IonicSelectableComponent
//   ],
//    declarations: [ArbitrationPartyAddPage]
// })
// export class ArbitrationPartyAddPageModule {}
